def funcion_modulo_2():
    print("Hola, soy el modulo_2 de mi paquete")