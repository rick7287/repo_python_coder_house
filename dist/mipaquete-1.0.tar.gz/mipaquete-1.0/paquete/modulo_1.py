def funcion_modulo_1():
    print("hola estoy en mi paquete")